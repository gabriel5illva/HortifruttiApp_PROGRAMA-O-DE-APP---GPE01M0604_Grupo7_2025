import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import EntregaCliente from '../screens/cliente/EntregaCliente';
import LoginScreen from '../screens/auth/LoginScreen';
import AdminHome from '../screens/admin/AdminHome';
import AdminNavigator from './AdminNavigator';

const Stack = createNativeStackNavigator();

export default function ClienteNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="EntregaCliente" component={EntregaCliente} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Admin" component={AdminHome} />
    </Stack.Navigator>
  );
}