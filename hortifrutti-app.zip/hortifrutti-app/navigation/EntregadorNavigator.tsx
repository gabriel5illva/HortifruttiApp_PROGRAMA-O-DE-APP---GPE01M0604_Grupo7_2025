    import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import EntregadorMapScreen from '../screens/auth/EntregadorMapScreen';
import CaminhoRestauranteScreen from '../screens/auth/CaminhoRestauranteScreen';
import CaminhoClienteScreen from '../screens/auth/CaminhoClienteScreen';

const Stack = createNativeStackNavigator();

export default function EntregadorStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="EntregadorMapa" component={EntregadorMapScreen} />
      <Stack.Screen name="CaminhoRestaurante" component={CaminhoRestauranteScreen} />
      <Stack.Screen name="CaminhoCliente" component={CaminhoClienteScreen} />
    </Stack.Navigator>
  );
}
