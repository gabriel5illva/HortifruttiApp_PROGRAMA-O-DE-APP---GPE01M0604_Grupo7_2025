import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import EntregaCliente from '../screens/cliente/EntregaCliente';
import LoginScreen from '../screens/auth/LoginScreen';
import AdminHome from '../screens/admin/AdminHome';
import AdminNavigator from './AdminNavigator';
import RastreioCliente from '../screens/cliente/RastreioCliente';
import BuscaCliente from '../screens/cliente/BuscaCliente';
import HomeCliente from '../screens/cliente/HomeCliente';
import ItensCliente from '../screens/cliente/ItensCliente';

const Stack = createNativeStackNavigator();

export default function ClienteNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="EntregaCliente" component={EntregaCliente} />
      <Stack.Screen name="ItensCliente" component={ItensCliente} />
      <Stack.Screen name="HomeCliente" component={HomeCliente} />
      <Stack.Screen name="BuscaCliente" component={BuscaCliente} />
      <Stack.Screen name="RastreioCliente" component={RastreioCliente} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Admin" component={AdminHome} />
    </Stack.Navigator>
  );
}